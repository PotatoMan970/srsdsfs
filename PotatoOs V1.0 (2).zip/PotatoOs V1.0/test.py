import webbrowser
import os
import random
import time
import turtle
import pickle
from tkinter import messagebox
from tkinter import *
print("e")


password = pickle.load(open(r"Users\PotatoMan\otherdata\password.dat", "rb"))

root = Tk(className="Login")
root.geometry('5000x5000')
root.config(bg='green')

l1 = Label(root, text="Potato Man", font='30x30')
l1.pack(side='top')
l1.config(bg='green')


def e():
    e = e1.get()
    if e == password:

        color = pickle.load(
            open(r"Users\PotatoMan\otherdata\backround.dat", "rb"))
        snakee = pickle.load(open(r"Users\PotatoMan\Apps\app.dat", "rb"))
        calciator = pickle.load(open(r"Users\PotatoMan\Apps\app2.dat", "rb"))
        rockps = pickle.load(open(r"Users\PotatoMan\Apps\app3.dat", "rb"))
        gen = pickle.load(open(r"Users\PotatoMan\Apps\app4.dat", "rb"))
        passgen = pickle.load(open(r"Users\PotatoMan\Apps\app5.dat", "rb"))
        textdocs = pickle.load(open(r"Users\PotatoMan\Apps\app6.dat", "rb"))
        browserr = pickle.load(open(r"Users\PotatoMan\Apps\app7.dat", "rb"))
        tictactoee = pickle.load(open(r"Users\PotatoMan\Apps\app8.dat", "rb"))

        rooot = Tk(className="VM test")
        rooot.geometry("5000x5000")
        rooot.config(bg=color)

        # Apps/Games
        def brouser():
            root = Tk(className="General")

            def search():
                searched = e1.get()
                url = searched
                webbrowser.open_new_tab(
                    'http://www.google.com/search?btnG=1&q=%s' % url)
            # lables
            l1 = Label(root, text='URL:')
            l1.grid(row=0, column=0, pady=1)
            # buttons
            b1 = Button(
                root, text='Search (you can not type in full urls yes)', command=search)
            b1.grid(row=0, column=2, pady=1)

            # enteries
            e1 = Entry(root)
            e1.grid(row=0, column=1, pady=1)
            root.mainloop()

        def tictaktoe():
            root = Tk(className="TicTacToe")

            p1l1, p1l2, p1l3, p1l4, p1l5, p1l6, p1l7, p1l8, p1l9 = False, False, False, False, False, False, False, False, False
            p2l1, p2l2, p2l3, p2l4, p2l5, p2l6, p2l7, p2l8, p2l9 = False, False, False, False, False, False, False, False, False

            def button1():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l1 = True
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=0, y=0)
                    b1.place(x=100000, y=1000000)
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                elif p2 == True:
                    p2l1 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=0, y=0)
                    b1.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

            def button2():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l2 = True
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=60, y=0)
                    b2.place(x=100000, y=1000000)
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                elif p2 == True:
                    p2l2 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=60, y=0)
                    b2.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

            def button3():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l3 = True
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=120, y=0)
                    b3.place(x=100000, y=1000000)
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                elif p2 == True:
                    p2l3 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=120, y=0)
                    b3.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

            def button4():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l4 = True
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=0, y=60)
                    b4.place(x=100000, y=1000000)
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                elif p2 == True:
                    p2l4 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=0, y=60)
                    b4.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

            def button5():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l5 = True
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=60, y=60)
                    b5.place(x=100000, y=1000000)
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                elif p2 == True:
                    p2l5 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=60, y=60)
                    b5.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

            def button6():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l6 = True
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=120, y=60)
                    b6.place(x=100000, y=1000000)
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                elif p2 == True:
                    p2l6 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=120, y=60)
                    b6.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

            def button7():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l7 = True
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=0, y=120)
                    b7.place(x=100000, y=1000000)
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                elif p2 == True:
                    p2l7 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=0, y=120)
                    b7.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

            def button8():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l8 = True
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=60, y=120)
                    b8.place(x=100000, y=1000000)
                elif p2 == True:
                    p2l8 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=60, y=120)
                    b8.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

            def button9():
                p1 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p1.dat", 'rb'))
                p2 = pickle.load(
                    open(r"Users\PotatoMan\otherdata\p2.dat", 'rb'))
                if p1 == True:
                    p1l9 = True
                    p1 = False
                    p2 = True
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))
                    l1 = Label(root, text='X')
                    l1.pack()
                    l1.place(x=120, y=120)
                    b9.place(x=100000, y=1000000)
                elif p2 == True:
                    p2l9 = True
                    l1 = Label(root, text='O')
                    l1.pack()
                    l1.place(x=120, y=120)
                    b9.place(x=100000, y=1000000)
                    p1 = True
                    p2 = False
                    pickle.dump(
                        p1, open(r"Users\PotatoMan\otherdata\p1.dat", 'wb'))
                    pickle.dump(
                        p2, open(r"Users\PotatoMan\otherdata\p2.dat", 'wb'))

                # buttons
            b1 = Button(root, command=button1)
            b1.pack()
            b1.place(x=0, y=0)
            b2 = Button(root, command=button2)
            b2.pack()
            b2.place(x=60, y=0)
            b3 = Button(root, command=button3)
            b3.pack()
            b3.place(x=120, y=0)
            b4 = Button(root, command=button4)
            b4.pack()
            b4.place(x=0, y=60)
            b5 = Button(root, command=button5)
            b5.pack()
            b5.place(x=60, y=60)
            b6 = Button(root, command=button6)
            b6.pack()
            b6.place(x=120, y=60)
            b7 = Button(root, command=button7)
            b7.pack()
            b7.place(x=0, y=120)
            b8 = Button(root, command=button8)
            b8.pack()
            b8.place(x=60, y=120)
            b9 = Button(root, command=button9)
            b9.pack()
            b9.place(x=120, y=120)
            # enteries
            root.mainloop()

        def textdocx():
            def save():
                w = e1.get()
                a = e2.get()
                s = e3.get()
                d = e4.get()
                e = e5.get()
                pickle.dump(
                    w, open(r'Users\PotatoMan\otherdata\textdoc', "wb"))
                pickle.dump(
                    a, open(r'Users\PotatoMan\otherdata\textdoc2', "wb"))
                pickle.dump(
                    s, open(r'Users\PotatoMan\otherdata\textdoc3', "wb"))
                pickle.dump(
                    d, open(r'Users\PotatoMan\otherdata\textdoc4', "wb"))
                pickle.dump(
                    e, open(r'Users\PotatoMan\otherdata\textdoc5', "wb"))

            root = Tk(className="TextBox")
            w = pickle.load(open(r'Users\PotatoMan\otherdata\textdoc', 'rb'))
            a = pickle.load(open(r'Users\PotatoMan\otherdata\textdoc2', 'rb'))
            s = pickle.load(open(r'Users\PotatoMan\otherdata\textdoc3', 'rb'))
            d = pickle.load(open(r'Users\PotatoMan\otherdata\textdoc4', 'rb'))
            e = pickle.load(open(r'Users\PotatoMan\otherdata\textdoc5', 'rb'))
            l1 = Label(root, text=w).pack()
            l1 = Label(root, text=a).pack()
            l1 = Label(root, text=s).pack()
            l1 = Label(root, text=d).pack()
            l1 = Label(root, text=e).pack()
            # buttons
            b1 = Button(root, text='save', command=save).pack()
            # enteries
            e1 = Entry(root)
            e1.pack()
            e2 = Entry(root)
            e2.pack()
            e3 = Entry(root)
            e3.pack()
            e4 = Entry(root)
            e4.pack()
            e5 = Entry(root)
            e5.pack()

            root.mainloop()

        def passwordgenerator():
            root = Tk(className="General")

            def generate():
                n = random.randint(1, 38)
                u = random.randint(1, 40)
                m = random.randint(1, 40)
                b = random.randint(1, 40)
                e = random.randint(1, 40)
                r = random.randint(1, 40)
                t = random.randint(1, 40)
                t2 = random.randint(1, 40)

                if n == 1:
                    n = 'a'
                elif n == 2:
                    n = 'b'
                elif n == 3:
                    n = 'c'
                elif n == 4:
                    n = 'd'
                elif n == 5:
                    n = 'e'
                elif n == 6:
                    n = 'f'
                elif n == 7:
                    n = 'g'
                elif n == 8:
                    n = 'h'
                elif n == 9:
                    n = 'i'
                elif n == 10:
                    n = 'j'
                elif n == 11:
                    n = 'k'
                elif n == 12:
                    n = 'l'
                elif n == 13:
                    n = 'm'
                elif n == 14:
                    n = 'o'
                elif n == 15:
                    n = 'p'
                elif n == 16:
                    n = 'q'
                elif n == 17:
                    n = 'r'
                elif n == 18:
                    n = 's'
                elif n == 19:
                    n = 't'
                elif n == 20:
                    n = 'u'
                elif n == 21:
                    n = 'v'
                elif n == 22:
                    n = 'w'
                elif n == 23:
                    n = 'x'
                elif n == 24:
                    n = 'y'
                elif n == 25:
                    n = 'z'
                elif n == 26:
                    n = '1'
                elif n == 27:
                    n = '2'
                elif n == 28:
                    n = '3'
                elif n == 29:
                    n = '4'
                elif n == 30:
                    n = '5'
                elif n == 31:
                    n = '6'
                elif n == 32:
                    n = '7'
                elif n == 33:
                    n = '8'
                elif n == 34:
                    n = '9'
                elif n == 35:
                    n = '0'
                elif n == 36:
                    n = '?'
                elif n == 37:
                    n = '.'
                elif n == 38:
                    n = '!'
                if u == 1:
                    u = 'a'
                elif u == 2:
                    u = 'b'
                elif u == 3:
                    u = 'c'
                elif u == 4:
                    u = 'd'
                elif u == 5:
                    u = 'e'
                elif u == 6:
                    u = 'f'
                elif u == 7:
                    u = 'g'
                elif u == 8:
                    u = 'h'
                elif u == 9:
                    u = 'i'
                elif u == 10:
                    u = 'j'
                elif u == 11:
                    u = 'k'
                elif u == 12:
                    u = 'l'
                elif u == 13:
                    u = 'm'
                elif u == 14:
                    u = 'o'
                elif u == 15:
                    u = 'p'
                elif u == 16:
                    u = 'q'
                elif u == 17:
                    u = 'r'
                elif u == 18:
                    u = 's'
                elif u == 19:
                    u = 't'
                elif u == 20:
                    u = 'u'
                elif u == 21:
                    u = 'v'
                elif u == 22:
                    u = 'w'
                elif u == 23:
                    u = 'x'
                elif u == 24:
                    u = 'y'
                elif u == 25:
                    u = 'z'
                elif u == 26:
                    u = '1'
                elif u == 27:
                    u = '2'
                elif u == 28:
                    u = '3'
                elif u == 29:
                    u = '4'
                elif u == 30:
                    u = '5'
                elif u == 31:
                    u = '6'
                elif u == 32:
                    u = '7'
                elif u == 33:
                    u = '8'
                elif u == 34:
                    u = '9'
                elif u == 35:
                    u = '0'
                elif u == 36:
                    u = '?'
                elif u == 37:
                    u = '.'
                elif u == 38:
                    u = '!'
                if m == 1:
                    m = 'a'
                elif m == 2:
                    m = 'b'
                elif m == 3:
                    m = 'c'
                elif m == 4:
                    m = 'd'
                elif m == 5:
                    m = 'e'
                elif m == 6:
                    m = 'f'
                elif m == 7:
                    m = 'g'
                elif m == 8:
                    m = 'h'
                elif m == 9:
                    m = 'i'
                elif m == 10:
                    m = 'j'
                elif m == 11:
                    m = 'k'
                elif m == 12:
                    m = 'l'
                elif m == 13:
                    m = 'm'
                elif m == 14:
                    m = 'o'
                elif m == 15:
                    m = 'p'
                elif m == 16:
                    m = 'q'
                elif m == 17:
                    m = 'r'
                elif m == 18:
                    m = 's'
                elif m == 19:
                    m = 't'
                elif m == 20:
                    m = 'm'
                elif m == 21:
                    m = 'v'
                elif m == 22:
                    m = 'w'
                elif m == 23:
                    m = 'x'
                elif m == 24:
                    m = 'y'
                elif m == 25:
                    m = 'z'
                elif m == 26:
                    m = '1'
                elif m == 27:
                    m = '2'
                elif m == 28:
                    m = '3'
                elif m == 29:
                    m = '4'
                elif m == 30:
                    m = '5'
                elif m == 31:
                    m = '6'
                elif m == 32:
                    m = '7'
                elif m == 33:
                    m = '8'
                elif m == 34:
                    m = '9'
                elif m == 35:
                    m = '0'
                elif m == 36:
                    m = '?'
                elif m == 37:
                    m = '.'
                elif m == 38:
                    m = '!'
                if b == 1:
                    b = 'a'
                elif b == 2:
                    b = 'b'
                elif b == 3:
                    b = 'c'
                elif b == 4:
                    b = 'd'
                elif b == 5:
                    b = 'e'
                elif b == 6:
                    b = 'f'
                elif b == 7:
                    b = 'g'
                elif b == 8:
                    b = 'h'
                elif b == 9:
                    b = 'i'
                elif b == 10:
                    b = 'j'
                elif b == 11:
                    b = 'k'
                elif b == 12:
                    b = 'l'
                elif b == 13:
                    b = 'b'
                elif b == 14:
                    b = 'o'
                elif b == 15:
                    b = 'p'
                elif b == 16:
                    b = 'q'
                elif b == 17:
                    b = 'r'
                elif b == 18:
                    b = 's'
                elif b == 19:
                    b = 't'
                elif b == 20:
                    b = 'b'
                elif b == 21:
                    b = 'v'
                elif b == 22:
                    b = 'w'
                elif b == 23:
                    b = 'x'
                elif b == 24:
                    b = 'y'
                elif b == 25:
                    b = 'z'
                elif b == 26:
                    b = '1'
                elif b == 27:
                    b = '2'
                elif b == 28:
                    b = '3'
                elif b == 29:
                    b = '4'
                elif b == 30:
                    b = '5'
                elif b == 31:
                    b = '6'
                elif b == 32:
                    b = '7'
                elif b == 33:
                    b = '8'
                elif b == 34:
                    b = '9'
                elif b == 35:
                    b = '0'
                elif b == 36:
                    b = '?'
                elif b == 37:
                    b = '.'
                elif b == 38:
                    b = '!'
                if e == 1:
                    e = 'a'
                elif e == 2:
                    e = 'e'
                elif e == 3:
                    e = 'c'
                elif e == 4:
                    e = 'd'
                elif e == 5:
                    e = 'e'
                elif e == 6:
                    e = 'f'
                elif e == 7:
                    e = 'g'
                elif e == 8:
                    e = 'h'
                elif e == 9:
                    e = 'i'
                elif e == 10:
                    e = 'j'
                elif e == 11:
                    e = 'k'
                elif e == 12:
                    e = 'l'
                elif e == 13:
                    e = 'e'
                elif e == 14:
                    e = 'o'
                elif e == 15:
                    e = 'p'
                elif e == 16:
                    e = 'q'
                elif e == 17:
                    e = 'r'
                elif e == 18:
                    e = 's'
                elif e == 19:
                    e = 't'
                elif e == 20:
                    e = 'e'
                elif e == 21:
                    e = 'v'
                elif e == 22:
                    e = 'w'
                elif e == 23:
                    e = 'x'
                elif e == 24:
                    e = 'y'
                elif e == 25:
                    e = 'z'
                elif e == 26:
                    e = '1'
                elif e == 27:
                    e = '2'
                elif e == 28:
                    e = '3'
                elif e == 29:
                    e = '4'
                elif e == 30:
                    e = '5'
                elif e == 31:
                    e = '6'
                elif e == 32:
                    e = '7'
                elif e == 33:
                    e = '8'
                elif e == 34:
                    e = '9'
                elif e == 35:
                    e = '0'
                elif e == 36:
                    e = '?'
                elif e == 37:
                    e = '.'
                elif e == 38:
                    e = '!'
                if r == 1:
                    r = 'a'
                elif r == 2:
                    r = 'r'
                elif r == 3:
                    r = 'c'
                elif r == 4:
                    r = 'd'
                elif r == 5:
                    r = 'r'
                elif r == 6:
                    r = 'f'
                elif r == 7:
                    r = 'g'
                elif r == 8:
                    r = 'h'
                elif r == 9:
                    r = 'i'
                elif r == 10:
                    r = 'j'
                elif r == 11:
                    r = 'k'
                elif r == 12:
                    r = 'l'
                elif r == 13:
                    r = 'r'
                elif r == 14:
                    r = 'o'
                elif r == 15:
                    r = 'p'
                elif r == 16:
                    r = 'q'
                elif r == 17:
                    r = 'r'
                elif r == 18:
                    r = 's'
                elif r == 19:
                    r = 't'
                elif r == 20:
                    r = 'r'
                elif r == 21:
                    r = 'v'
                elif r == 22:
                    r = 'w'
                elif r == 23:
                    r = 'x'
                elif r == 24:
                    r = 'y'
                elif r == 25:
                    r = 'z'
                elif r == 26:
                    r = '1'
                elif r == 27:
                    r = '2'
                elif r == 28:
                    r = '3'
                elif r == 29:
                    r = '4'
                elif r == 30:
                    r = '5'
                elif r == 31:
                    r = '6'
                elif r == 32:
                    r = '7'
                elif r == 33:
                    r = '8'
                elif r == 34:
                    r = '9'
                elif r == 35:
                    r = '0'
                elif r == 36:
                    r = '?'
                elif r == 37:
                    r = '.'
                elif r == 38:
                    r = '!'
                if t == 1:
                    t = 'a'
                elif t == 2:
                    t = 'r'
                elif t == 3:
                    t = 'c'
                elif t == 4:
                    t = 'd'
                elif t == 5:
                    t = 'r'
                elif t == 6:
                    t = 'f'
                elif t == 7:
                    t = 'g'
                elif t == 8:
                    t = 'h'
                elif t == 9:
                    t = 'i'
                elif t == 10:
                    t = 'j'
                elif t == 11:
                    t = 'k'
                elif t == 12:
                    t = 'l'
                elif t == 13:
                    t = 'r'
                elif t == 14:
                    t = 'o'
                elif t == 15:
                    t = 'p'
                elif t == 16:
                    t = 'q'
                elif t == 17:
                    t = 'r'
                elif t == 18:
                    t = 's'
                elif t == 19:
                    t = 't'
                elif t == 20:
                    t = 'r'
                elif t == 21:
                    t = 'v'
                elif t == 22:
                    t = 'w'
                elif t == 23:
                    t = 'x'
                elif t == 24:
                    t = 'y'
                elif t == 25:
                    t = 'z'
                elif t == 26:
                    t = '1'
                elif t == 27:
                    t = '2'
                elif t == 28:
                    t = '3'
                elif t == 29:
                    t = '4'
                elif t == 30:
                    t = '5'
                elif t == 31:
                    t = '6'
                elif t == 32:
                    t = '7'
                elif t == 33:
                    t = '8'
                elif t == 34:
                    t = '9'
                elif t == 35:
                    t = '0'
                elif t == 36:
                    t = '?'
                elif t == 37:
                    t = '.'
                elif t == 38:
                    t = '!'
                if t2 == 1:
                    t2 = 'a'
                elif t2 == 2:
                    t2 = 'r'
                elif t2 == 3:
                    t2 = 'c'
                elif t2 == 4:
                    t2 = 'd'
                elif t2 == 5:
                    t2 = 'r'
                elif t2 == 6:
                    t2 = 'f'
                elif t2 == 7:
                    t2 = 'g'
                elif t2 == 8:
                    t2 = 'h'
                elif t2 == 9:
                    t2 = 'i'
                elif t2 == 10:
                    t2 = 'j'
                elif t2 == 11:
                    t2 = 'k'
                elif t2 == 12:
                    t2 = 'l'
                elif t2 == 13:
                    t2 = 'r'
                elif t2 == 14:
                    t2 = 'o'
                elif t2 == 15:
                    t2 = 'p'
                elif t2 == 16:
                    t2 = 'q'
                elif t2 == 17:
                    t2 = 'r'
                elif t2 == 18:
                    t2 = 's'
                elif t2 == 19:
                    t2 = 't'
                elif t2 == 20:
                    t2 = 'r'
                elif t2 == 21:
                    t2 = 'v'
                elif t2 == 22:
                    t2 = 'w'
                elif t2 == 23:
                    t2 = 'x'
                elif t2 == 24:
                    t2 = 'y'
                elif t2 == 25:
                    t2 = 'z'
                elif t2 == 26:
                    t2 = '1'
                elif t2 == 27:
                    t2 = '2'
                elif t2 == 28:
                    t2 = '3'
                elif t2 == 29:
                    t2 = '4'
                elif t2 == 30:
                    t2 = '5'
                elif t2 == 31:
                    t2 = '6'
                elif t2 == 32:
                    t2 = '7'
                elif t2 == 33:
                    t2 = '8'
                elif t2 == 34:
                    t2 = '9'
                elif t2 == 35:
                    t2 = '0'
                elif t2 == 36:
                    t2 = '?'
                elif t2 == 37:
                    t2 = '.'
                elif t2 == 38:
                    t2 = '!'
                password = str(n) + str(m) + str(b) + str(e) + \
                    str(r) + str(t) + str(t2)
                l1 = Label(root, text=password).pack()
            # lables
            l1 = Label(root, text='Thank you for testing.').pack()

            # buttons
            b1 = Button(root, text='Generate random password',
                        command=generate).pack()
            # enteries
            root.mainloop()

        def rannumgen():
            def generate():
                uno = e1.get()
                dos = e2.get()
                n = random.randint(int(uno), int(dos))
                l1 = Label(root, text=n).pack()
            root = Tk(className="General")
            e1 = Entry(root)
            e1.pack()
            e2 = Entry(root)
            e2.pack()
            b1 = Button(root, text='Generate', command=generate).pack()

        def rps():

            def test():
                n = random.randint(1, 3)
                if n == 2:
                    l1 = Label(root, text='ROBOT WINS!!!').pack(side='bottom')
                elif n == 3:
                    l1 = Label(root, text='YOU WIN!!!').pack(side='bottom')
                elif n == 1:
                    l1 = Label(root, text='no one wins.').pack(side='bottom')

            def test2():
                n = random.randint(1, 3)
                if n == 3:
                    l1 = Label(root, text='ROBOT WINS!!!').pack(side='bottom')
                elif n == 1:
                    l1 = Label(root, text='YOU WIN!!!').pack(side='bottom')
                elif n == 2:
                    l1 = Label(root, text='no one wins.').pack(side='bottom')

            def test3():
                n = random.randint(1, 3)
                if n == 1:
                    l1 = Label(root, text='ROBOT WINS!!!').pack(side='bottom')
                elif n == 2:
                    l1 = Label(root, text='YOU WIN!!!').pack(side='bottom')
                elif n == 3:
                    l1 = Label(root, text='no one wins.').pack(side='bottom')

            root = Tk(className="General")

            # lables
            l1 = Label(root, text='Thank you for testing.').pack(side='bottom')

            # buttons
            b1 = Button(root, text='Rock', command=test).pack(side='top')
            b1 = Button(root, text='Paper', command=test2).pack(side='top')
            b1 = Button(root, text='Sissors', command=test3).pack(side='top')

            # enteries
            root.mainloop()

        def settings():
            color = pickle.load(
                open(r"Users\PotatoMan\otherdata\backround.dat", "rb"))
            snakee = pickle.load(open(r"Users\PotatoMan\Apps\app.dat", "rb"))
            calciator = pickle.load(
                open(r"Users\PotatoMan\Apps\app2.dat", "rb"))
            rockps = pickle.load(open(r"Users\PotatoMan\Apps\app3.dat", "rb"))
            gen = pickle.load(open(r"Users\PotatoMan\Apps\app4.dat", "rb"))
            passgen = pickle.load(open(r"Users\PotatoMan\Apps\app5.dat", "rb"))
            textdocs = pickle.load(
                open(r"Users\PotatoMan\Apps\app6.dat", "rb"))
            browser = pickle.load(open(r"Users\PotatoMan\Apps\app7.dat", "rb"))
            root = Tk(className="Settings")
            root.geometry('500x500')
            root.config(bg='grey')

            message = StringVar()

            message.set('Potato')

            def files():
                root = Tk(className="General")

                # lables
                l1 = Label(root, text='Apps').pack(side='top')
                l2 = Label(root, text='Calcuator')
                l3 = Label(root, text='Snake')
                l4 = Label(root, text='Rock Paper Sissors')
                l5 = Label(root, text='Random Number Generator')
                l6 = Label(root, text='Random Password Generator')
                l7 = Label(root, text='Text Documents')
                l8 = Label(root, text='Other Data')
                l9 = Label(root, text=color)
                l10 = Label(root, text='Browser')

                if calciator == True:
                    l2.pack()
                else:
                    pass
                if snakee == True:
                    l3.pack()
                else:
                    pass
                if rockps == True:
                    l4.pack()
                else:
                    pass
                if gen == True:
                    l5.pack()
                else:
                    pass
                if passgen == True:
                    l6.pack()
                else:
                    pass
                if textdocs == True:
                    l7.pack()
                else:
                    pass
                if browserr == True:
                    l10.pack()
                else:
                    pass
                l8.pack()
                l9.pack()
                # buttons

                # enteries
                root.mainloop()

            def test():
                root = Tk(className="General")

                # def
                def bakround():
                    color2 = e1.get()
                    rooot.config(bg=color2)
                    pickle.dump(color2, open(
                        r"Users\PotatoMan\otherdata\backround.dat", "wb"))

                    # lables
                l1 = Label(root, text='Thank you for testing.').pack()

                # buttons
                b1 = Button(root, text='Apply Backround',
                            command=bakround).pack()

                # enteries
                e1 = Entry(root)
                e1.pack()

                # code here
                # ________________________

            def test2():

                def ghddsdfseffd():
                    password = e1.get()
                    print(password)
                    pickle.dump(password, open(
                        r"Users\PotatoMan\otherdata\password.dat", "wb"))

                root = Tk(className="General")
                # buttons
                b1 = Button(root, text='Save', command=ghddsdfseffd).pack()
                # enteries
                e1 = Entry(root)
                e1.pack()
                root.mainloop()

            l1 = Label(root, text="SETTINGS")

            l1.pack(side='top')

            b1 = Button(root, text="Backround", command=test).pack(side='top')
            b2 = Button(root, text='Files', command=files).pack()
            b3 = Button(root, text='Password', command=test2).pack()

        def cal():
            class Window(Frame):
                def __init__(self, master=None):
                    Frame.__init__(self, master)
                    self.master = master
            # Creating result text field
                    self.resultField = Text(
                        master, bg="#FFFFFF", fg="#000000", height=1, width=20)
                    self.resultField.insert(INSERT, "0")
                    self.resultField.grid(row=0, columnspan=4)
            # Creating number and operation buttons
                    b1 = Button(master, text="1",
                                command=lambda: self.notice(1))
                    b2 = Button(master, text="2",
                                command=lambda: self.notice(2))
                    b3 = Button(master, text="3",
                                command=lambda: self.notice(3))
                    bPlus = Button(master, text="+",
                                   command=lambda: self.notice("+"))
                    b4 = Button(master, text="4",
                                command=lambda: self.notice(4))
                    b5 = Button(master, text="5",
                                command=lambda: self.notice(5))
                    b6 = Button(master, text="6",
                                command=lambda: self.notice(6))
                    bMinus = Button(master, text="-",
                                    command=lambda: self.notice("-"))
                    b7 = Button(master, text="7",
                                command=lambda: self.notice(7))
                    b8 = Button(master, text="8",
                                command=lambda: self.notice(8))
                    b9 = Button(master, text="9",
                                command=lambda: self.notice(9))
                    bMultip = Button(master, text="*",
                                     command=lambda: self.notice("*"))
                    b0 = Button(master, text="0",
                                command=lambda: self.notice(0))
                    bLeft = Button(master, text="(",
                                   command=lambda: self.notice("("))
                    bRight = Button(master, text=")",
                                    command=lambda: self.notice(")"))
                    bDivide = Button(master, text="/",
                                     command=lambda: self.notice("/"))
            # Aligning number and operation buttons
                    b1.grid(row=1, column=0)
                    b2.grid(row=1, column=1)
                    b3.grid(row=1, column=2)
                    bPlus.grid(row=1, column=3)
                    b4.grid(row=2, column=0)
                    b5.grid(row=2, column=1)
                    b6.grid(row=2, column=2)
                    bMinus.grid(row=2, column=3)
                    b7.grid(row=3, column=0)
                    b8.grid(row=3, column=1)
                    b9.grid(row=3, column=2)
                    bMultip.grid(row=3, column=3)
                    b0.grid(row=4, column=0)
                    bLeft.grid(row=4, column=1)
                    bRight.grid(row=4, column=2)
                    bDivide.grid(row=4, column=3)
            # Creating and aligning calculation buttons
                    bCalculate = Button(
                        master, text="=", command=self.displayRes)
                    bClear = Button(master, text="Clear", command=self.clear)
                    bCalculate.grid(row=5, column=0, columnspan=2)
                    bClear.grid(row=5, column=2, columnspan=2)

                def notice(self, num):
                    if self.resultField.get("0.0", END) == "0\n":
                        self.resultField.delete("0.0", END)
                    self.resultField.insert(INSERT, str(num))

                def clear(self):
                    self.resultField.delete("0.0", END)
                    self.resultField.insert(INSERT, "0")

                def displayRes(self):
                    res = self.calculate(self.resultField.get("0.0", END)[:-1])
                    self.resultField.delete("0.0", END)
                    self.resultField.insert(INSERT, str(res))

                def calculate(self, task):
                    if task == "ERROR":
                        return "ERROR"  # don't proceed if error happened in underlying call
                    try:
                        return(float(task))
                    except ValueError:
                        if ")" in task:
                            level = 0
                            maxLevelStartIndex = 0
                            maxLevelEndIndex = 0
                            for i in range(0, len(task)):
                                if task[i] == "(":
                                    level += 1
                                    maxLevelStartIndex = i
                                if task[i] == ")":
                                    level -= 1
                            if level != 0:
                                messagebox.showerror(
                                    "Error", "ERROR: brackets don't match: %i layers too much in expression %s" % (level, task))
                                return "ERROR"
                            for i in range(maxLevelStartIndex, len(task)):
                                if task[i] == ")":
                                    maxLevelEndIndex = i
                                    break
                            newTask = task[:maxLevelStartIndex] + str(self.calculate(
                                task[maxLevelStartIndex+1:maxLevelEndIndex])) + task[maxLevelEndIndex+1:]
                            return self.calculate(newTask)
                        elif "+" in task:
                            tesk = task.split("+")
                            res = self.calculate(tesk[0])
                            for t in tesk[1:]:
                                res += self.calculate(t)
                            return res
                        elif "-" in task:
                            tesk = task.split("-")
                            res = self.calculate(tesk[0])
                            for t in tesk[1:]:
                                res -= self.calculate(t)
                            return res
                        elif "*" in task:
                            tesk = task.split("*")
                            res = self.calculate(tesk[0])
                            for t in tesk[1:]:
                                res *= self.calculate(t)
                            return res
                        elif "/" in task:
                            tesk = task.split("/")
                            res = self.calculate(tesk[0])
                            for t in tesk[1:]:
                                try:
                                    res /= self.calculate(t)
                                except ZeroDivisionError:
                                    messagebox.showerror(
                                        "Error", "ERROR: division by 0")
                                    return "ERROR"
                            return res
                        else:
                            messagebox.showerror(
                                "Error", "ERROR: invalid expression")
                            return "ERROR"
            root = Tk()
            app = Window(root)
            root.wm_title("Calculator")

        def appstore():
            root = Tk(className="General")

            # lables
            l1 = Label(root, text='Thank you for testing.').pack()

            # buttons
            b1 = Button(root, text="install ''snake''",
                        command=einstall).pack()
            b2 = Button(root, text="install ''caloutator''",
                        command=ainstall).pack()
            b3 = Button(root, text="install ''Rock Paper Sissors''",
                        command=rpsinstall).pack()
            b4 = Button(root, text="install ''Random Number Generator''",
                        command=geninstall).pack()
            b5 = Button(root, text="install ''Random Password Generator''",
                        command=passgeninstall).pack()
            b6 = Button(root, text="install ''Text Docx''",
                        command=textinstall).pack()
            b7 = Button(root, text="install ''Browser''",
                        command=browserinstall).pack()
            b8 = Button(root, text="install ''TicTacToe''",
                        command=tiktaktoeinstall).pack()
            b9 = Button(root, text="''install timer''",
                        command=timerinstall).pack()
            # enteries

        def appstore2():
            root = Tk(className="General")

            # lables
            l1 = Label(root, text='Thank you for testing.').pack()

            # buttons
            b1 = Button(root, text="uninstall ''snake''",
                        command=euninstall).pack()
            b2 = Button(root, text="uninstall ''caloutator''",
                        command=auninstall).pack()
            b3 = Button(root, text="uninstall ''Rock Paper Sissors''",
                        command=rpsuninstall).pack()
            b4 = Button(root, text="uninstall ''Random Number Generator''",
                        command=genuninstall).pack()
            b5 = Button(root, text="uninstall ''Random Password Generator''",
                        command=passgenuninstall).pack()
            b6 = Button(root, text="uninstall ''Text Docx''",
                        command=textuninstall).pack()
            b7 = Button(root, text="uninstall ''Browser''",
                        command=browseruninstall).pack()
            b8 = Button(root, text="uninstall ''TicTacToe''",
                        command=tiktaktoeuninstall).pack()
            b9 = Button(root, text="''uninstall timer''",
                        command=timeruninstall).pack()

            # enteries

        def snake():
            delay = 0.1

            # Score
            score = 0
            high_score = 0

            # Set up the screen
            wn = turtle.Screen()
            wn.title("Snake Game by @TokyoEdTech")
            wn.bgcolor("green")
            wn.setup(width=600, height=600)
            wn.tracer(0)  # Turns off the screen updates

            # Snake head
            head = turtle.Turtle()
            head.speed(0)
            head.shape("square")
            head.color("black")
            head.penup()
            head.goto(0, 0)
            head.direction = "stop"

            # Snake food
            food = turtle.Turtle()
            food.speed(0)
            food.shape("circle")
            food.color("red")
            food.penup()
            food.goto(0, 100)

            segments = []

            # Pen
            pen = turtle.Turtle()
            pen.speed(0)
            pen.shape("square")
            pen.color("white")
            pen.penup()
            pen.hideturtle()
            pen.goto(0, 260)
            pen.write("Score: 0  High Score: 0", align="center",
                      font=("Courier", 24, "normal"))

            # Functions
            def go_up():
                if head.direction != "down":
                    head.direction = "up"

            def go_down():
                if head.direction != "up":
                    head.direction = "down"

            def go_left():
                if head.direction != "right":
                    head.direction = "left"

            def go_right():
                if head.direction != "left":
                    head.direction = "right"

            def move():
                if head.direction == "up":
                    y = head.ycor()
                    head.sety(y + 20)

                if head.direction == "down":
                    y = head.ycor()
                    head.sety(y - 20)

                if head.direction == "left":
                    x = head.xcor()
                    head.setx(x - 20)

                if head.direction == "right":
                    x = head.xcor()
                    head.setx(x + 20)

            # Keyboard bindings
            wn.listen()
            wn.onkeypress(go_up, "w")
            wn.onkeypress(go_down, "s")
            wn.onkeypress(go_left, "a")
            wn.onkeypress(go_right, "d")

            # Main game loop
            while True:
                wn.update()

                # Check for a collision with the border
                if head.xcor() > 290 or head.xcor() < -290 or head.ycor() > 290 or head.ycor() < -290:
                    time.sleep(1)
                    head.goto(0, 0)
                    head.direction = "stop"

                    # Hide the segments
                    for segment in segments:
                        segment.goto(1000, 1000)

                    # Clear the segments list
                    segments.clear()

                    # Reset the score
                    score = 0

                    # Reset the delay
                    delay = 0.1

                    pen.clear()
                    pen.write("Score: {}  High Score: {}".format(
                        score, high_score), align="center", font=("Courier", 24, "normal"))

                # Check for a collision with the food
                if head.distance(food) < 20:
                    # Move the food to a random spot
                    x = random.randint(-290, 290)
                    y = random.randint(-290, 290)
                    food.goto(x, y)

                    # Add a segment
                    new_segment = turtle.Turtle()
                    new_segment.speed(0)
                    new_segment.shape("square")
                    new_segment.color("grey")
                    new_segment.penup()
                    segments.append(new_segment)

                    # Shorten the delay
                    delay -= 0.001

                    # Increase the score
                    score += 10

                    if score > high_score:
                        high_score = score

                    pen.clear()
                    pen.write("Score: {}  High Score: {}".format(
                        score, high_score), align="center", font=("Courier", 24, "normal"))

                # Move the end segments first in reverse order
                for index in range(len(segments)-1, 0, -1):
                    x = segments[index-1].xcor()
                    y = segments[index-1].ycor()
                    segments[index].goto(x, y)

                # Move segment 0 to where the head is
                if len(segments) > 0:
                    x = head.xcor()
                    y = head.ycor()
                    segments[0].goto(x, y)

                move()

                # Check for head collision with the body segments
                for segment in segments:
                    if segment.distance(head) < 20:
                        time.sleep(1)
                        head.goto(0, 0)
                        head.direction = "stop"

                        # Hide the segments
                        for segment in segments:
                            segment.goto(1000, 1000)

                        # Clear the segments list
                        segments.clear()

                        # Reset the score
                        score = 0

                        # Reset the delay
                        delay = 0.1

                        # Update the score display
                        pen.clear()
                        pen.write("Score: {}  High Score: {}".format(
                            score, high_score), align="center", font=("Courier", 24, "normal"))

                time.sleep(delay)
            wn.mainloop()

        def timer():
            power2 = True

            root = Tk(className="General")
            print(power2)

            number = 0

            def Increase():
                global l1
                global number
                number += 1
                l1.config(text=number)
                print(number)

            def Decrease():
                global l1
                global number
                number -= 1
                l1.config(text=number)
                print(number)

            def start():
                global l1
                print('started')
                global l1
                global number
                global power
                power = True
                l1.config(text=number)
                while power == True:
                    l1.config(text=number)
                    if number == 0:
                        l1.config(text=number)
                        print('finished')
                        power = False
                    elif number > 0:
                        time.sleep(1)
                        number -= 1
                        hruskr = number
                        print(number)
                    else:
                        l1.conifg(text=number)
                        print('finished')

                # lables
            b1 = Button(root, text="Increase",
                        command=Increase).pack(side='top')
            b2 = Button(root, text="Deacrease",
                        command=Decrease).pack(side='top')
            b3 = Button(root, text='Start', command=start).pack(side='top')

            # buttons
            l1 = Label(root, text=number)
            l1.pack(side='bottom')
            # enteries

            root.mainloop()

        def timerinstall():
            djsgksfh = True
            pickle.dump(djsgksfh, open(r"Users\PotatoMan\Apps\app.dat9", "wb"))
            b8.pack()
            b8.place(x=800, y=995)

        def einstall():
            oajkra = True
            pickle.dump(oajkra, open(r"Users\PotatoMan\Apps\app.dat", "wb"))
            b4.pack()
            b4.place(x=150, y=995)

        def euninstall():
            oajkra = False
            pickle.dump(oajkra, open(r"Users\PotatoMan\Apps\app.dat", "wb"))
            b4.place(x=900, y=10000)

        def ainstall():
            oabkra = True
            pickle.dump(oabkra, open(r"Users\PotatoMan\Apps\app2.dat", "wb"))
            b5.pack()
            b5.place(x=200, y=995)

        def auninstall():
            oabkra = False
            pickle.dump(oabkra, open(r"Users\PotatoMan\Apps\app2.dat", "wb"))
            b5.place(x=900, y=10000)

        def rpsinstall():
            oakkra = True
            pickle.dump(oakkra, open(r"Users\PotatoMan\Apps\app3.dat", "wb"))
            b6.pack()
            b6.place(x=260, y=995)

        def rpsuninstall():
            oakkra = False
            pickle.dump(oakkra, open(r"Users\PotatoMan\Apps\app3.dat", "wb"))
            b6.place(x=900, y=10000)

        def geninstall():
            aabkra = True
            pickle.dump(aabkra, open(r"Users\PotatoMan\Apps\app4.dat", "wb"))
            b7.pack()
            b7.place(x=360, y=995)

        def genuninstall():
            aabkra = False
            pickle.dump(aabkra, open(r"Users\PotatoMan\Apps\app4.dat", "wb"))
            b7.place(x=900, y=10000)

        def passgeninstall():
            aabkrb = True
            pickle.dump(aabkrb, open(r"Users\PotatoMan\Apps\app5.dat", "wb"))
            b8.pack()
            b8.place(x=460, y=995)

        def passgenuninstall():
            aabkrb = False
            pickle.dump(aabkrb, open(r"Users\PotatoMan\Apps\app5.dat", "wb"))
            b8.place(x=900, y=10000)

        def textinstall():
            aabkzb = True
            pickle.dump(aabkzb, open(r"Users\PotatoMan\Apps\app6.dat", "wb"))
            b9.pack()
            b9.place(x=560, y=995)

        def timeruninstall():
            djsgksfh = False
            pickle.dump(djsgksfh, open(r"Users\PotatoMan\Apps\app9.dat", "wb"))
            b12.place(x=900, y=10000)

        def textuninstall():
            aabkzb = False
            pickle.dump(aabkzb, open(r"Users\PotatoMan\Apps\app6.dat", "wb"))
            b9.place(x=900, y=10000)

        def browserinstall():
            hfkzsh = True
            pickle.dump(hfkzsh, open(r"Users\PotatoMan\Apps\app7.dat", "wb"))
            b10.pack()
            b10.place(x=660, y=995)

        def browseruninstall():
            hfkzsh = False
            pickle.dump(hfkzsh, open(r"Users\PotatoMan\Apps\app7.dat", "wb"))
            b10.place(x=100000, y=1000000)

        def tiktaktoeinstall():
            hfjksgk = True
            pickle.dump(hfjksgk, open(r"Users\PotatoMan\Apps\app8.dat", "wb"))
            b11.place(x=750, y=995)

        def tiktaktoeuninstall():
            hfjksgk = False
            pickle.dump(hfjksgk, open(r"Users\PotatoMan\Apps\app8.dat", "wb"))
            b11.place(x=100000, y=1000000)

        # Buttons
        b2 = Button(rooot, text="Settings", command=settings)
        b1 = Button(rooot, text='uninstall', command=appstore2)
        b3 = Button(rooot, text='store', command=appstore)
        b4 = Button(rooot, text='snake', command=snake)
        b5 = Button(rooot, text='calcuator', command=cal)
        b6 = Button(rooot, text='rock paper sissors', command=rps)
        b7 = Button(rooot, text='Random Number Generator', command=rannumgen)
        b8 = Button(rooot, text="Random Password Generator",
                    command=passwordgenerator)
        b9 = Button(rooot, text='Text Documents', command=textdocx)
        b10 = Button(rooot, text='Browser', command=brouser)
        b11 = Button(rooot, text='TicTacTor', command=tictaktoe)

        # packs
        b3.pack()
        b2.pack()
        b1.pack()

        # Place
        b3.place(x=100, y=995)
        b2.place(x=0, y=995)
        b1.place(x=50, y=995)

        # if statments
        if tictactoee == True:
            tiktaktoeinstall()
        if snakee == True:
            einstall()
        if calciator == True:
            ainstall()
        if rockps == True:
            rpsinstall()
        if gen == True:
            geninstall()
        if passgen == True:
            passgeninstall()
        if textdocs == True:
            textinstall()
        if browserr == True:
            browserinstall()
        rooot.mainloop()


e1 = Entry(root, text="General")
e1.pack(side='top')

b1 = Button(root, text='login', command=e).pack(side='top')

root.mainloop()
